export class Manager {
  snipeURL: string;

  apiToken: string;

  constructor(snipeURL: string, apiToken: string) {
    this.snipeURL = snipeURL;
    this.apiToken = apiToken;
  }
}
